<h1 align="center">TODO APP</h1>

## About:
Todo App is a simple  website application to keep a check of your tasks with very easy to use interface. It can help you to add or delete the daily works from your list and you can also remove once you are done with it.

## Technology Stack:
  1) React
  2) CSS
  3) HTML
